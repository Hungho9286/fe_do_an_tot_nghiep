<div class="container-fluid">
    @yield('content')
</div>
