<!-- Left Column -->
<div class="col-sm-3">

    <!-- List-Group Panel -->
    <div class="panel panel-default">
        <div class="panel-heading">
            <h1 class="panel-title"><span class="glyphicon glyphicon-random"></span> Chức năng</h1>
        </div>
        <div class="list-group">
            <a href="/" class="list-group-item">Trang của bạn</a>
            <a href="/thoi-khoa-bieu" class="list-group-item">Thời khóa biểu </a>
            <a href="/thong-tin-ca-nhan" class="list-group-item">Thông tin cá nhân</a>
            <a href="/dang-ky-hoc-phan" class="list-group-item">Đăng ký học phần</a>
            <a href="/dong-hoc-phi" class="list-group-item">Đóng học phí</a>
            <a href="/xem-diem" class="list-group-item">Xem điểm</a>
        </div>
    </div>

    {{-- <!-- Text Panel -->
    <div class="panel panel-default">
        <div class="panel-heading">
            <h1 class="panel-title"><span class="glyphicon glyphicon-cog"></span> Dramatically Engage</h1>
        </div>

        <div class="panel-body">
            <p>Objectively innovate empowered manufactured products whereas parallel platforms. Holisticly predominate extensible testing procedures for reliable supply chains. Dramatically engage top-line web services vis-a-vis cutting-edge deliverables.</p>
            <p><button class="btn btn-default">Engage</button></p>
        </div>
    </div> --}}

</div><!--/Left Column-->
