<div class="col-sm-6">

    @yield('content')
</div><!--/Center Column-->
