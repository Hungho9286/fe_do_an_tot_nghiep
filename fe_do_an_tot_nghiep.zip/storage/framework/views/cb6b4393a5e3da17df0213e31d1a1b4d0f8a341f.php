
<?php $__env->startSection('content'); ?>
<h1>THỜI KHÓA BIỂU</h1>
<div ng-app="thoiKhoaBieuGiangVien" ng-controller="ThoiKhoaBieuController">


    
    <table class="table table-bordered">
    <thead class="thead-light">
      <tr>
        <th scope="col">Phòng</th>
        <th scope="col">Thứ 2</th>
        <th scope="col">Thứ 3</th>
        <th scope="col">Thứ 4</th>
        <th scope="col">Thứ 5</th>
        <th scope="col">Thứ 6</th>
        <th scope="col">Thứ 7</th>
        <th scope="col">CN</th>
      </tr>
    </thead>
    <tbody id="body-table">
      <tr ng-repeat="tkb in thoiKhoaBieu">
        <th scope="row" style="background-color:beige"><%tkb.ten_phong_hoc%></th>
          <td ng-repeat="count in [1,2,3,4,5,6,7]">
            <div ng-repeat="lp in tkb.lich|filter:{thu_trong_tuan:count}">
                    <strong><%lp.mon_hoc%></strong>
                    <p><%lp.tiet_bat_dau%> &#8594; <%lp.tiet_ket_thuc%></p>
                    <p><%lp.thoi_gian_bat_dau%> &#8594; <%lp.thoi_gian_ket_thuc%></p>
                    <p ng-if="lp.giang_vien_1!='Empty'"><%lp.giang_vien_1%></p>
                    <p ng-if="lp.giang_vien_1=='Empty'"><%lp.lop_hoc.giang_vien_chu_nhiem.ten_giang_vien%></p>
            </div>
          </td>
      </tr>
    </tbody>
  </table>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular.min.js"></script>

<script>
    var app = angular.module("thoiKhoaBieuGiangVien", [],function($interpolateProvider) {
    $interpolateProvider.startSymbol('<%');
    $interpolateProvider.endSymbol('%>');
    });
    app.controller("ThoiKhoaBieuController",function($scope,$http){
        $http( 
          {
            url:'<?php echo e(env('SERVER_URL')); ?>/api/giang-vien/thoi-khoa-bieu/<?php echo e(Session::get('ma_gv')); ?>',
            method: 'GET',
            headers:{
               "Authorization":"Bearer <?php echo e(Session::get('access_token_gv')); ?>" 
            },
          }).then($response=>{
            $scope.thoiKhoaBieu=$response.data;
            console.log($response.data);
      
        });
});

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.giangvien.giangvien', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\0306201537\Laravel\do_an_tot_nghiep\fe_do_an_tot_nghiep\resources\views/giangvien/thoikhoabieu.blade.php ENDPATH**/ ?>