<?php
$accessToken = request()->cookie('access_token');
$id_sinh_vien=request()->cookie('id_sinh_vien');
$url="http://127.0.0.1:8000/api/sinh-vien/".$id_sinh_vien;
$ch=curl_init();
curl_setopt($ch,CURLOPT_URL,$url);
// curl_setopt($ch,CURLOPT_POST,true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
// curl_setopt($ch, CURLOPT_POSTFIELDS,
//     "id=".$request->id_sinh_vien);
curl_setopt($ch,CURLOPT_HTTPHEADER,array("Authorization: Bearer $accessToken"));
$head=curl_exec($ch);
//dd($head);
curl_close($ch);
$data=json_decode($head);
//dd($data->khoa_hoc);
?>

<!DOCTYPE html>
<!-- Template by Quackit.com -->
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <title>Cổng thông tin trực tuyến CKC</title>
    <link rel="icon" type="image/png" href="<?php echo e(asset('assets/images/logos/logoct.png')); ?>" />
    <!-- Bootstrap Core CSS -->

    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">

    <!-- Custom CSS: You can use this stylesheet to override any Bootstrap styles and/or apply your own styles -->
    <link href="<?php echo e(asset('css/custom.css')); ?>" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <?php echo $__env->yieldContent('css'); ?>

</head>

<body>

<?php echo $__env->make('layouts.client.block.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container-fluid">
        <?php echo $__env->make('layouts.client.block.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('layouts.client.block.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	  <!-- Right Column -->
	  <div class="col-sm-3">



			<!-- Progress Bars -->
			

			


	  </div><!--/Right Column -->

	</div><!--/container-fluid-->




    <?php echo $__env->make('layouts.client.block.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('script'); ?>
</body>

</html>
<?php /**PATH F:\0306201537\Laravel\do_an_tot_nghiep\fe_do_an_tot_nghiep\resources\views/layouts/client/client.blade.php ENDPATH**/ ?>