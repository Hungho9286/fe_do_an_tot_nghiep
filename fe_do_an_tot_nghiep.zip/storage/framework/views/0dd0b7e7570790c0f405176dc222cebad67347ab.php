<?php $__env->startSection('content'); ?>
<h1>THỜI KHÓA BIỂU</h1>
<div ng-app="myApp" ng-controller="ThoiKhoaBieuController">
    <div class="alert alert-info" role="alert">
    Sinh viên chọn tuần để xem lịch
    </div>
    <div>
        <label for="">Năm học: </label>
        <select class="form-select form-select-sm" aria-label=".form-select-sm example">
            <option selected>Chọn năm học</option>
            <option value="1">2020 - 2021</option>
            <option value="2">2021 - 2022</option>
            <option value="3">2022 - 2023</option>
        </select>
        <label for="">Học kỳ: </label>
        <select class="form-select form-select-sm" aria-label=".form-select-sm example">
            <option selected>chọn học kỳ</option>
            <option value="1">Học kỳ 1</option>
            <option value="2">Học kỳ 2</option>
            <option value="3">Học kỳ 3</option>
        </select>
    </div>
    
    <table class="table table-bordered">
    <thead class="thead-light">
      <tr>
        <th scope="col">Phòng</th>
        <th scope="col">Thứ 2</th>
        <th scope="col">Thứ 3</th>
        <th scope="col">Thứ 4</th>
        <th scope="col">Thứ 5</th>
        <th scope="col">Thứ 6</th>
        <th scope="col">Thứ 7</th>
        <th scope="col">CN</th>
      </tr>
    </thead>
    <tbody id="body-table">
      <tr ng-repeat="tkb in thoiKhoaBieu">
        <th scope="row" style="background-color:beige"><%tkb.ten_phong_hoc%></th>
          <td ng-repeat="count in [1,2,3,4,5,6,7]">
            <div ng-repeat="lp in tkb.lich|filter:{thu_trong_tuan:count}">
                    <strong><%lp.mon_hoc%></strong>
                    <p><%lp.tiet_bat_dau%> &#8594; <%lp.tiet_ket_thuc%></p>
                    <p><%lp.thoi_gian_bat_dau%> &#8594; <%lp.thoi_gian_ket_thuc%></p>
                    <p><%lp.giang_vien_1%></p>
            </div>
          </td>
      </tr>
    </tbody>
  </table>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular.min.js"></script>

<script>
    var app = angular.module("myApp", [],function($interpolateProvider) {
    $interpolateProvider.startSymbol('<%');
    $interpolateProvider.endSymbol('%>');
    });
    app.controller("ThoiKhoaBieuController",function($scope,$http){
        $http.get('http://127.0.0.1:8000/api/thoi-khoa-bieu-cua-sinh-vien/2').then($response=>{
            $scope.thoiKhoaBieu=$response.data;
        });
});


    // app.filter("ThemThoiKhoaBieu",function(){
    //     return function(input,thu,phong,phongduyet,index,dongcuoi){

    //         console.log(index);
    //         console.log(nLast);
    //       console.log("thu index "+thu_index);
    //       console.log("thu "+thu);
    //       console.log("phong duyet "+phongduyet);
    //       console.log("phong "+phong);
    //       console.log("--------");
    //       if(dongcuoi==false){
    //         if(thu<=thu_index&&phong==phongduyet){
    //             return input;
    //         }
    //         if(thu==thu_index&&phong==phongduyet){

    //             return input;
    //         }

    //       }else{
    //         if(index+1==nLast){
    //             if(thu==thu_index&&phong==phongduyet){
    //                 return input;
    //             }
    //             thu_index=1;
    //         }
    //         else{

    //             thu_index=thu_index+1;
    //             return input;
    //         }



    //       }
    //       return '';

    //     }
    // });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.client.client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\0306201537\Laravel\do_an_tot_nghiep\my_project\resources\views/layouts/fe/thoikhoabieu.blade.php ENDPATH**/ ?>