<div class="col-sm-6">

    <?php echo $__env->yieldContent('content'); ?>
</div><!--/Center Column-->
<?php /**PATH F:\0306201537\Laravel\do_an_tot_nghiep\fe_do_an_tot_nghiep\resources\views/layouts/client/block/main.blade.php ENDPATH**/ ?>