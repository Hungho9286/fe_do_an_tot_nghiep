

<?php $__env->startSection('css'); ?>
<style>



    .div-box-class{
        margin-left: 20px;
        margin-top: 20px;
        background-color: rgb(132, 132, 254);
        border-radius:3px;
        width: 30%;
        height:100px;
        position: relative;
        border:solid 1px rgb(237, 237, 237);
        cursor: pointer;
    }
    .div-name-subject{
        color: white;
        font-size:1.5em;
        font-weight:bold
    }
    .div-code-class{
        color: white
    }
    .div-name-class{
        height:30%;
        width:100%;
        background-color:white;
        position: absolute;
        bottom:0px;
        right:0px;
        color: rgb(105, 105, 105);
        text-align:right;
        padding-right:10px;
        border-radius:0px 0px 2px 2px;
        font-weight:800;
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div ng-app="myApp">
<span>Lớp học phần</span>
<br>
<div ng-controller="DanhSachLopHocPhanController">
    <div id="danh-sach-lop-hoc-phan">
        <div class="d-flex flex-wrap">
            <div class="p-2 bd-highlight div-box-class" ng-repeat="lopHocPhan in danhSachLopHocPhanCuaGiangVien" ng-click="DanhSachSinhVien(lopHocPhan.id_lop_hoc_phan)">
                <div>
                    <div class="d-flex justify-content-start div-name-subject" ><%lopHocPhan.mon_hoc.ten_mon_hoc%></div>
                    <div class="d-flex justify-content-start div-code-class">Mã lớp: <%lopHocPhan.id_lop_hoc_phan%></div>
                </div>
                <div class="div-name-class">
                    <div >Lớp: <%lopHocPhan.lop_hoc.ten_lop_hoc%></div>
                </div>
            </div>
        </div>
    </div>


</div>
<br>
<span>Lớp chủ nhiệm</span>
<div ng-controller="DanhSachLopChuNhiemController">
    <div id="danh-sach-lop-chu-nhiem">
        <div class="d-flex flex-wrap">
            <div class="p-2 bd-highlight div-box-class" ng-repeat="lopChuNhiem in DanhSachLopChuNhiem"  ng-click="DanhSachSinhVienChuNhiem(lopChuNhiem.lop_hoc.id)">
                <div>
                    <div class="d-flex justify-content-start div-name-subject" ><%lopChuNhiem.lop_hoc.ten_lop_hoc%></div>
                </div>
                <div class="div-name-class">
                    <div >Lớp: <%lopChuNhiem.lop_hoc.ten_lop_hoc%></div>
                </div> 
            </div>
        </div>
    </div>


</div>
</div>






<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular.min.js"></script>
<script>
        var app = angular.module("myApp", [],function($interpolateProvider) {
    $interpolateProvider.startSymbol('<%');
    $interpolateProvider.endSymbol('%>');
    });
    app.controller("DanhSachLopHocPhanController",function($scope,$http){
        $http({
            method:"GET",
            url:'<?php echo e(env('SERVER_URL')); ?>/api/giang-vien/danh-sach-lop-hoc-phan/<?php echo e(Session::get('ma_gv')); ?>',
            datas:{
                'option':0,
            },
            headers:{
               "Authorization":"Bearer <?php echo e(Session::get('access_token_gv')); ?> " 
            },
        }).then(response=>{
            console.log(response.data);
            $scope.danhSachLopHocPhanCuaGiangVien=response.data;
            // console.log($scope.danhSachLopHocPhanCuaGiangVien);
            $scope.DanhSachSinhVien=function($id_lop_hoc_phan){
                $scope.showListLopHocPhan=false;
                
                $scope.danhSachLopHocPhanCuaGiangVien.forEach(element => {
                    if(element.id_lop_hoc_phan==$id_lop_hoc_phan){
                        window.location.href='/giangvien/lop-hoc-phan-cua-giang-vien?id='+element.id_lop_hoc_phan+'&type=1';
                    }
                });
            }
        })
    });
    app.controller("DanhSachLopChuNhiemController",function($scope,$http){
        $http({
            method: "GET",
            url:'<?php echo e(env('SERVER_URL')); ?>/api/giang-vien/danh-sach-lop-chu-nhiem/<?php echo e(Session::get('ma_gv')); ?>',
            headers:{
                "Authorization":"Bearer <?php echo e(Session::get('access_token_gv')); ?>" 
            }
        }).then(response=>{
            $scope.DanhSachLopChuNhiem=response.data;
            console.log($scope.DanhSachLopChuNhiem);
            $scope.DanhSachSinhVienChuNhiem=function($id_lop_chu_nhiem){
                $scope.showListLopHocChuNhiem=false;
                
                $scope.DanhSachLopChuNhiem.forEach(element => {
                    if(element.lop_hoc.id==$id_lop_chu_nhiem){
                        console.log("DOo");
                        window.location.href='/giangvien/lop-chu-nhiem-cua-giang-vien?id='+element.lop_hoc.id+'&type=0';
                    }
                });
            }
        })
    })
</script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.giangvien.giangvien', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\0306201537\Laravel\do_an_tot_nghiep\fe_do_an_tot_nghiep\resources\views/giangvien/trangchu.blade.php ENDPATH**/ ?>