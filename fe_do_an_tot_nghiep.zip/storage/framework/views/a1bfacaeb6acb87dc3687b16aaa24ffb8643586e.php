<div class="container-fluid">
    <?php echo $__env->yieldContent('content'); ?>
</div>
<?php /**PATH F:\0306201537\Laravel\do_an_tot_nghiep\fe_do_an_tot_nghiep\resources\views/layouts/giangvien/blocks/main.blade.php ENDPATH**/ ?>