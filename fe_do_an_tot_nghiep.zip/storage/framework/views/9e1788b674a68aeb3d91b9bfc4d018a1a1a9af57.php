<?php $__env->startSection('content'); ?>
<div ng-app="myApp" ng-controller="DanhSachSinhVienTheoLopHocPhanController">
    <a href="<?php echo e(route('trang-chu-giang-vien')); ?>" class="btn btn-outline-primary">Trở lại</a>
    <ul class="list-group" >
        <li class="list-group-item" ng-repeat="sinhVien in lopHocPhan.danh_sach_sinh_vien">
            <div class="row justify-content-around">
                <div class="col-8">
                  <div>MSSV: <%sinhVien.mssv%></div>
                  <div>Lớp: CĐTH20F</div>
                  <div>Email: <%sinhVien.email%></div>
                  <div>Tên: <%sinhVien.ho_ten%></div>
                </div>
                <div class="col-4">
                    <button type="button" class="btn btn-success" ng-click="XemThongTinSinhVien(sinhVien.id)">Xem thông tin</button>
                    <button type="button" class="btn btn-primary" ng-click="XemDiemSinhVien(sinhVien.id)">Xem điểm</button>
                </div>
            </div>
        </li>
    </ul>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular.min.js"></script>
<script>
    var app = angular.module("myApp", [],function($interpolateProvider) {
    $interpolateProvider.startSymbol('<%');
    $interpolateProvider.endSymbol('%>');
    });
    $id_giang_vien=1;
    app.controller("DanhSachSinhVienTheoLopHocPhanController",function($scope,$http){
        $http({
            method:"GET",
            url:"<?php echo e(env('SERVER_URL')); ?>/api/giang-vien/danh-sach-lop-hoc-phan/"+$id_giang_vien,
            params:{
                'opition':1,
                'id_lop_hoc_phan':<?php echo e($id_lop_hoc_phan); ?>,
            },
            headers:{
                "Authorizations":"Bearer token"
            }
        }).then($response=>{
            $scope.lopHocPhan=$response.data;

            $scope.XemThongTinSinhVien=function($id_sinh_vien){
                window.location.href="/giang-vien/danh-sach-lop-hoc-phan/danh-sach-sinh-vien/<?php echo e($id_lop_hoc_phan); ?>/thong-tin-sinh-vien?id_sinh_vien="+$id_sinh_vien;
            }
        })
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.giangvien.giangvien', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\0306201537\Laravel\do_an_tot_nghiep\fe_do_an_tot_nghiep\resources\views/giangvien/danhsachsinhvientheolop.blade.php ENDPATH**/ ?>