<footer>
    

    <div class="small-print">
        <div class="container">
            <p><a href="#">Terms &amp; Conditions</a> | <a href="#">Privacy Policy</a> | <a href="#">Contact</a></p>
            <p>Copyright &copy; Example.com 2015 </p>
        </div>
    </div>
</footer>

<!-- jQuery -->
<script src="<?php echo e(asset('js/jquery-1.11.3.min.js')); ?>"></script>

<!-- Bootstrap Core JavaScript -->
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>

<!-- IE10 viewport bug workaround -->
<script src="<?php echo e(asset('js/ie10-viewport-bug-workaround.js')); ?>"></script>

<!-- Placeholder Images -->
<script src="<?php echo e(asset('js/holder.min.js')); ?>"></script>



<?php /**PATH F:\0306201537\Laravel\do_an_tot_nghiep\fe_do_an_tot_nghiep\resources\views/layouts/client/block/footer.blade.php ENDPATH**/ ?>